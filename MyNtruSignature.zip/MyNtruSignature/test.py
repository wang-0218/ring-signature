# from time import *
# # import Polynomial as pol
# begin_time = time()
# result1=pol.Subtraction2([1,2,3,4,6],[5,7,8,4,6],3)
# result=pol.Subtraction2(result1,[5,6,7,8,9],3)
# print("result=",result)
#
#
#
#

# import math
# def bits(n):
#     return math.ceil(math.log2(n))
#
# # print(bits(1024))
# # print(bits(1024)//8)
#
# print(bin(8))
#
# print(bits(57855321987765443124658))
# import numpy as np
# blist=[]
# for i in range(100):
#     b1 = np.random.randint(1, 50, 15)
#     b=b1.tolist()
#     blist.append(b)
# # print("blist=",blist)
# import sys
# af=0
# fKeg=[[[44, 34, 8], [32, 19,20], [4, 35, 4], [3, 53,5]],[[1,2],[3,4],[5,6],[6]]]
# for i in range(len(fKeg)):
#     print("第一层",fKeg[i])
#     for j in range(len(fKeg[i])):
#         print("第二层", fKeg[i][j])
#         for k in range(len(fKeg[i][i])):
#             print("第三层",fKeg[i][j][k])
#             af = sys.getsizeof(fKeg[i][j][k]) / 1024 + af
#
# print("af=", af)
# # print(sys.getsizeof(a)/1024)
# end_time = time()
#
# run_time = end_time - begin_time
# print("run_time=", run_time)

import math


# def findMinX(num, rem, k):
#     x = 1
#     while (True):
#         j = 0
#         while (j < k):
#             if (x % num[j] != rem[j]):
#                 break
#             j += 1
#         if (j == k):
#             return x
#         x += 1


def gcd(m, n):
    if (n != 0):
        return gcd(n, m % n)
    return m


def isPrime(n):
    if (n <= 1):
        return False
    if (n <= 3):
        return True
    if (n % 2 == 0 or n % 3 == 0):
        return False
    i = 5
    while (i * i <= n):
        if (n % i == 0 or n % (i + 2) == 0):
            return False
        i = i + 6
    return True


def inverseOfEulersTotient(z):
    n = 1
    mcount = 0
    nlist = []
    while (1):
        for m in range(1, n):
            if (gcd(m, n) == 1):
                mcount += 1
        if (mcount == z):
            nlist.append(n)
        mcount = 0
        n += 1
        if (n > 3000):  # guessing an integer for upper bound
            print(nlist)
            break


def eulersTotient(n):
    z = 1
    for i in range(2, n):
        if (gcd(i, n) == 1):
            z += 1
    print("z=",z)
    return z


def main():
    # num = [19, 18, 17]
    # rem = [10, 12, 14]
    # k = len(num)
    # print("x is", findMinX(num, rem, k))  # ANSWER: x = 48
    print(eulersTotient(771))
    # inverseOfEulersTotient(1024)
    # print(isPrime(1543))
    # for n in range(1, 1024):
    #     if (eulersTotient(n) == eulersTotient(n + 1)):
    #         print(n, " - ", n + 1)


if __name__ == "__main__":
    main()
