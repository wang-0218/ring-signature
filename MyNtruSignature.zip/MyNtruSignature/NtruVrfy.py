import Polynomial as pol
from time import *
import KegGen as kg
import numpy as np
import operator as op

import NtruGroupSignature as NGS
begin_time = time()

def GroupSVrfy(gn_pk,M,r,za1list,za2list,N):
    Tstr=[]
    for j in range(N):
        # print("j=",j)
        t, n = NGS.HashFun(M, r, j)
        Tstr.append(t)
        # print("哈希过的消息长度=", n)
        # print("Tstr=", Tstr)
    for i in range(N):
        result=pol.Subtraction2(pol.Multiplication2(gn_pk[i],za1list[i],3),za2list[i],3)
        # if op.eq(result, Tstr[i]) == True:
        #     print("成功")
        # else:
        #     print("失败")


def main ():
    fKeg,hKeg,sigskkeg,sigpkKeg=kg.NtruGroupGen(23131,1285,1024,3,5740638)
    # print("fKeg=",fKeg)
    # print("hKeg=",hKeg)
    # print("sigskkeg=",sigskkeg)
    # print("sigpkkeg=",sigpkKeg)
    # Nj = np.random.randint(1, 2)


    # print("sigskkeyNj=",sigskkeg[Nj][Nj])

    r,z1list,z2list=NGS. NtruGrouSi(hKeg,sigpkKeg,sigskkeg, "hjjghj",1024,1024)
    GroupSVrfy(sigpkKeg, "hjjghj",r,z1list,z2list,1024)

    return 0
if __name__ == '__main__':
    main()
end_time = time()
run_time = end_time - begin_time
print("run_time=", run_time)