from time import *
import random
import hashlib
import numpy as np
import KegGen as kg
import Polynomial as pol
import operator as op
import sys

begin_time = time()
def HashFun(m,r,i):
    my_list = []
    str1=[]
    if type(m)!=str:
        str1.append(str(m))
    else:
        str1.append(m)
    for j in range(len(r)):
        st=str(r[j])
        str1.append(st)
    str1.append(str(i))
    #print("str1=",str1)
    strl="".join(str1)
    #print("strl=",strl)
    message=strl

    message1 = hashlib.sha3_512()
    message1.update(str(message).encode('utf-8'))
    # print("message1.hexdigest=", message1.hexdigest())
    anes = message1.hexdigest() + "\n"

    # print(anes.__len__())
    for i in range(anes.__len__()):
        if ord(anes[i]) in range(97, 123):
            my_list.append(int(anes[i], 16))


        elif ord(anes[i]) in range(48, 58):
            my_list.append(int(anes[i], 16))


        elif anes[i] == anes[-1]:
            # print(my_list)
            break
    n=len(my_list)
    #print("my_list length=", len(my_list))
    # print("my_list=", my_list)
    return my_list,n

#HashFun("jkshjhiu",[1,3,5],2)

def NtruGrouSi(enhpk,sigpk,gn_sk,mu_list,n,N):
    #Tstr存储了每个群成员对消息M的哈希摘要
    Tstr=[]
    #SList1,SList2表示存储随机采出的si1,和si2
    Slist1=[]
    Slist2=[]
    # s=np.random.seed(1000)
    #r为随机选取

    Nj = 0

    r = np.random.randint(1, 100000, n+1)
    # print("r=", r)

    for j in range(N):
        # print("j=",j)
        t,n1=HashFun(mu_list,r,j)
        Tstr.append(t)
        # print("哈希过的消息长度=",n)
        # print("Tstr=",Tstr)
#对成员j采取sj1,sj2
    # sj1=np.mod(np.random.randint(1,50,5),3)
    # print("sj1=",sj1)
    # sj2 = np.mod(np.random.randint(3, 50, 5),3)
    # print("sj2=",sj2)
    for i in range(N):
        rs11=np.mod(np.random.randint(1,100000,n+1),3)
        rs1=rs11.tolist()

        Slist1.append(rs1)
    # print("Slist1=",Slist1)
    for i in range(N):
        rs22=np.mod(np.random.randint(1,100000,n+1),3)
        rs2=rs22.tolist()
        Slist2.append(rs2)
    # print("Slist2=",Slist2)
    for i in range(N):
     result=pol.Subtraction2(pol.Multiplication2(sigpk[i],Slist1[i],3),Slist2[i],3)
     # if op.eq(result, Tstr[i]) == True:
     #     print("成功")
     # else:
     #     print("失败")
    # print("result=",result)

    #z1list,z2list表示每个群成员对消息的签名运算
    z1list=[]
    z2list=[]
    #s1list,s2list存储错误分布采样的si1,si2
    s1list=[]
    s2list=[]
    #e1list,e2list存储错误分布采样的e1,e2
    e1list=[]
    e2list=[]
    for i in range(N):
        # zr1=np.random.randint(0,10,5)
        # z1list.append(zr1)
        # zr2=np.random.randint(0,10,5)
        # z2llist.append(zr2)
        sr1=np.random.randint(1,100000,n+1)
        s1list.append(sr1)
        sr2=np.random.randint(1,100000,n+1)
        s2list.append(sr2)
        er1=np.random.randint(1,100000,n+1)
        e1list.append(er1)
        er2=np.random.randint(1,100000,n+1)
        e2list.append(er2)
    for i in range(N):
        za11=pol.Add(pol.Multiplication2(enhpk[i],s1list[i],3),pol.Multiplication(e1list[i],3,3),3)
        za12=pol.Add(za11,Slist1[i],3)
        z1list.append(za12)
    # print(" z1list=", z1list)
    for i in range(N):
        za21=pol.Add(pol.Multiplication2(enhpk[i],s2list[i],3),pol.Multiplication(e2list[i],3,3),3)
        za22=pol.Add(za21,Slist2[i],3)
        z2list.append(za22)
    # print(" z2list=", z2list)
    ar = 0
    az1=0
    az2=0
    for i in range(len(r)):
        ar = sys.getsizeof(r[i]) / 1024 + ar
        # ar=ar+(len(bin(r[i]))-2)
    # print("ar的长度为:", ar)
    for i in range(len(z1list)):
        az1 = sys.getsizeof(z1list[i]) / 1024 + az1

    # print("az1的长度为:", az1)
    for i in range(len(z2list)):
        az2 = sys.getsizeof(z2list[i]) / 1024 + az2

    # print("az2的长度为:", az2)
    # print("签名长度为：",ar+az1+az2)
    return r,z1list,z2list
#NtruGrouSi(3,2)


def main ():
    # fKeg,hKeg,sigskkeg,sigpkKeg=kg.NtruGroupGen(23131,1285,1024,3,5740638)
    # print("fKeg=",fKeg)
    # print("hKeg=",hKeg)
    # print("sigskkeg=",sigskkeg)
    # print("sigpkkeg=",sigpkKeg)
    # Nj = np.random.randint(1, 2)
    # print("Nj=", Nj)
    # print("sigskkeyNj=",sigskkeg[Nj][Nj])

    # NtruGrouSi(hKeg,sigpkKeg,sigskkeg, "gghj",1024,1024)

    return
if __name__ == '__main__':
    main()
end_time = time()

run_time = end_time - begin_time
# print("run_time=", run_time)
