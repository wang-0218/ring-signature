import random
import numpy as np
import time
def polynomial(n,id):
    #指定随机种子,保证每次随机数都相同
    random.seed(id)
    #index 生成一个一维n的随机数矩阵
    index = random.sample(range(0,n),n)
    #生成一个一维n个的矩阵,每个值都为1
    pol = np.ones(n)
    #利用for循环将随机一维矩阵中的随机数和pol中的每一个元素相乘得到随机系数的多项式
    for i in range(n):
        pol[i] = pol[i] * index[i]
    #index随机数,pol为随机多项式
    return index, pol

def multiplication(pol1,pol2):
    #传入参数为两个多项式pol1,pol2
    #相乘之后的结果为mulp长度为2n-1,我们要求a[n,2n-1]
    #mulp = list(np.convolve(pol1, pol2))
    mulp = np.convolve(pol1,pol2)
    n = len(pol1)
    #切片
    bigger_n = mulp[0:n-1]
    bigger_n1 = mulp[n-1:]
    n2 = len(bigger_n)
    #合并同类项
    for i in range(n2):
        bigger_n1[i] = (bigger_n[i] + bigger_n1[i])
    #remainder = [x % 3 for x in bigger_n1]
    remainder = bigger_n1 % 3

    return bigger_n1, remainder

# def test_of_time(n,id1,id2):
#     pol1 = polynomial(n,id1)[1]
#     pol2 = polynomial(n,id2)[1]
#     time_b = time.perf_counter()
#     out_put = multiplication(pol1, pol2)
#     time_e = time.perf_counter()
#     time_cost = time_e - time_b
#     return  time_cost

if __name__ == '__main__':

    n = 32
    id1 = 1
    id2 = 2
    #测试数据
    #pol1 = np.array([n,2,1])
    #pol2 = np.array([n,2,1])
    #随机生成的两个不同的多项式
    timeb = time.clock()
    pol1 = polynomial(n,id1)[1]
    pol2 = polynomial(n,id2)[1]

    timee = time.clock()
    print('time',timee - timeb)
   # print(test_of_time(n,id1,id2))
    #打印随机生成随机数和多项式