from numpy import mod
from time import *
import numpy as np

# 提取多项式系数
def extract_info(str_polynimial):
    length = len(str_polynimial)
    add = 1  # 记录加号位置
    for i in range(length):
        if i == 0:  # 获取x的最高次幂指数及其系数
            j = 0
            while (j != length and str_polynimial[j] != 'x'):
                j += 1
            if j + 1 == length or str_polynimial[j + 1] != '^':
                index_list = [0] * 2
                str_coefficient = "".join([str(item) for item in str_polynimial[0:j]])
                if str_coefficient == "":
                    str_coefficient = '1'
                index = 1
                index_list[index] = int(str_coefficient)
            elif str_polynimial[j + 1] == '^':
                k = j + 2
                while (k != length and str_polynimial[k] != '+' and str_polynimial[k] != '-'):
                    k += 1
                str_index = "".join([str(item) for item in str_polynimial[j + 2:k]])
                highest_index = int(str_index)  # 获取最高次幂指数
                index_list = [0] * (highest_index + 1)
                index = highest_index
                if j == 0:  # 首项系数为1的情况下
                    index_list[index] = 1
                else:
                    str_coefficient = "".join([str(item) for item in str_polynimial[0:j]])
                    index_list[index] = int(str_coefficient)

        elif str_polynimial[i] != '+' and str_polynimial[i] != '-':
            continue
        else:
            j = i
            while (j != length and str_polynimial[j] != 'x'):
                j += 1
            # 截取x某一方幂前的系数
            str_coefficient = "".join([str(item) for item in str_polynimial[i + 1:j]])
            if str_coefficient == "":  # 如果str_coefficient未截取到字符串，证明该项系数为1，令str_coefficient='1'
                str_coefficient = '1'
            if str_polynimial[i] == '-':  # 如若系数为负，更正系数
                str_coefficient = "-" + str_coefficient
            # 下面确定并截取x的方幂次数
            if j == length:  # 如果已遍历至字符串末位，证明x对应方幂为0
                str_index = '0'
            elif (j + 1) == length or str_polynimial[j + 1] == '+' or str_polynimial[
                j + 1] == '-':  # 如果x紧接着的字符为’+‘或此时x为最后一个字符，则证明该x对应的方幂次数为1
                str_index = '1'
            else:
                k = j + 2
                while (k != length and str_polynimial[k] != '+' and str_polynimial[k] != '-'):
                    k += 1
                # while语句执行完后，str_polynimial[k]='+'
                str_index = "".join([str(item) for item in str_polynimial[j + 2:k]])  # 截取x对应的方幂次数
            # 修改列表对应参数
            index_list[int(str_index)] = int(str_coefficient)
    index_list.reverse()
    # print("index_list",index_list)
    return index_list


# 定义多项式的加法，默认参数list1、list2不等长，p=2
def Add(list1, list2, p):
    # p=2
    a = list1.copy()
    b = list2.copy()
    result = []
    if len(a) > len(b):
        # 将列表反向a=[3,2,1]->a=[1,2,3]
        b.reverse()
        # 将列表b扩展为与a等长的列表
        c = b.extend([0] * (len(a) - len(b)))
        b.reverse()
        max = len(a)
    else:
        a.reverse()
        a.extend([0] * (len(b) - len(a)))
        a.reverse()
        max = len(b)
    for i in range(max):
        result.append(mod((a[i] + b[i]), p))
    for j in range(len(result)):  # 除去列表最左端无意义的0
        if result[0] == 0:
            result.remove(0)
        else:
            break
    # print("result=", result)
    return result


# 定义多项式在数域Zp中
def PoyMod(list1, p):
    a = list1.copy()
    result = []
    for i in range(len(a)):
        result.append(mod(a[i], p))
    # print("result=",result)
    return result


# PoyMod([5,-7,8,9],3)

# 定义多项式列表与数的乘法，参数list为被乘的多项式列表，a为int型的乘数。计算数域为Zp,p=2
def Multiplication(list, a, p):
    result = []

    for i in range(len(list)):
        result.append(mod((list[i] * a), p))

    #print("result=", result)
    return result


# Multiplication([1,2,3],3,2)
# print("Multiplication([1,2,3],3,2)",Multiplication([1,2,3],3,2))
# 定义多项式与多项式的乘法，参数list1，list2均为多项式的列表表示法。计算数域为Zp
def Multiplication2(list1, list2, p):
    a = list1.copy()
    b = list2.copy()

    result = [0]
    for i in range(len(b)):
        product = Multiplication(a, b[i], p)
        product.extend([0] * (len(b) - 1 - i))
        result = Add(result, product, p)
    #print("result=", result)
    return result


# Multiplication2([1,2,4],[2,3,4])

# 定义多项式列表表示的减法，要求参数list1与list2等长，返回结果仍为等长的列表。计算数域为Zp
def Subtraction(list1, list2, p):
    # p=2
    a = list1.copy()
    b = list2.copy()
    result = []
    for i in range(len(a)):
        result.append(mod((a[i] - b[i]), p))
    return result


# 计算数域为Zp
def Subtraction2(list1, list2, p):
    a = list1.copy()
    b = list2.copy()
    if len(a) < len(b):
        a.reverse()
        a.extend([0] * (len(b) - len(a)))
        a.reverse()
    elif len(a) > len(b):
        b.reverse()
        b.extend([0] * (len(a) - len(b)))
        b.reverse()
    result = Subtraction(a, b, p)
    #print("result=", result)
    return result


# Subtraction2([1,2,4,5],[2,3,5])
# 实现多项式带余除法,参数list1、list2均为列表，list1为被除多项式返回多项式商q的列表与余式r的列表
def Division(list1, list2, p):
    # 此处注意要深拷贝，浅拷贝会修改传进来的参数值
    r = list1.copy()
    b = list2.copy()
    if len(r) < len(b):
        return [0], list1
    q = [0] * (len(r) - len(b) + 1)
    for i in range(len(q)):
        if len(r) >= len(b):
            index = len(r) - len(b) + 1  # 确定所得商是商式的第index位
            q[-index] = int(r[0] / b[0])
            # 更新被除多项式
            b_ = b.copy()
            b_.extend([0] * (len(r) - len(b)))
            b_ = Multiplication(b_, q[i], p)
            r = Subtraction(r, b_, p)
            for j in range(len(r)):  # 除去列表最左端无意义的0
                if r[0] == 0:
                    r.remove(0)
                else:
                    break
        else:
            break
    # print("q=",q)
    # print("r=",r)
    return q, r
    # return q


#Division([9,5,6,7],[1,2,3],2)

# 扩展欧几里得算法，输入两个多项式列表list1、list2，返回二者的最大公因式列表d，以及满足d=u*list1+v*list2的u和v
# 默认list1、list2不等于0
def Extend_Euclid(list1, list2, p):
    f = list1.copy()
    g = list2.copy()
    u_2 = [1]
    u_1 = [0]
    v_2 = [0]
    v_1 = [1]
    while (g != []):
        q, r = Division(f, g, p)
        u = Subtraction2(u_2, Multiplication2(q, u_1, p), p)
        v = Subtraction2(v_2, Multiplication2(q, v_1, p), p)
        f, g = g, r
        u_2, u_1 = u_1, u
        v_2, v_1 = v_1, v
    # d为最大公约数，列表2模列表1的逆元为v,v为逆元
    d, u, v = f, u_2, v_2
    print("d=",d)
    print("u=",u)
    print("v",v)
    return d, u, v


#Extend_Euclid([1, 2, 3], [4, 5, 6], 2)
# f=Multiplication([6, 5, 3, 5, 5, 3, 3, 2, 4, 0],-1,7)
# print(f)
# d,u,v=Extend_Euclid([1,2,3],f,2)
#元素求逆
def Zn_inv(a, n):
    if a < 0:
        a += n

    t = 0
    r = n
    new_t = 1
    new_r = a

    while new_r != 0:
        quotient = r // new_r
        t, new_t = new_t, t - quotient * new_t
        r, new_r = new_r, r - quotient * new_r

    if r > 1:
        raise ValueError(f'{a} has no inverse in ℤ_{n}.')
    if t < 0:
        t += n

    assert (t * a) % n == 1  # sanity check

    return t
# print(Zn_inv(7,11))
def Invser(list,p):
    InvList=[]
    a=list.copy()
    for i in range(len(a)):
        if mod(a[i],p)==0:
            InvList.append(a[i])
            continue
        bi=Zn_inv(a[i], p)
        InvList.append(bi)
    print("InvList=",InvList)
    return InvList
#Invser([1,3,5,6,11,7,8,13,9],7)


n=256
q=2049
list1 = np.random.randint(1, 100000, n)
list2 = np.random.randint(1, 100000, n)
begin_time = time()
Multiplication2(list1, list2, q)

end_time = time()

run_time = end_time - begin_time
print("run_time=", run_time)