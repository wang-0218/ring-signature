from time import *
import numpy as np
import random
import Polynomial as pol
from hsnf import row_style_hermite_normal_form,smith_normal_form,column_style_hermite_normal_form
import math
import sys

begin_time = time()


def conmodl(q1,l):
    if (l%2)==0:
        l=l/2
        # print("l=",l)
    if q1 != 0:
        while np.mod((q1 - 1) ,l ) != 0:
            q1 = int(input("重新输入q="))
            # q1 = Primenum()
    q = int(q1)
    l=int(l)
    print("q=",q)
    print("l=",l)
    return q,l

# conmodl(65,128)

def Euler(l):
    # if (l%2)==0:
    #     l=l/2
    #     # print("l=",l)
    m = l
    n = int(l)
    for i in range(2, n):
        if np.mod(m, i) == 0:
            n -= n / i
        while np.mod(m, i) == 0:
            m /= i
        i = i * i
    if m > 1:
        n -= n / m
    print("n=",int(n))

    return int(n)




# n = Euler(80, 559)


def NTRUEncKegGen(n, p, q):
    # NtEkg=[]
    f1 = np.random.randint(1, 100000, n+1)
    f1 = f1.tolist()
    print("f1=", f1)
    #print("f1=", f1)
    # f = pol.Add(pol.Multiplication2(p, f1, q), [1], q)
    f = pol.Add(pol.Multiplication(f1,p,q), [1], q)
    #print("f=", f)
    g1 = np.random.randint(1, 100000, n+1)
    g1 = g1.tolist()
    g = pol.PoyMod(g1, q)
    #print("g1=", g1)
    #print("g=", g)
    # h, r = pol.Division(pol.Multiplication2(p,g , q), f, q)
    h, r = pol.Division(pol.Multiplication(g,p,q), f, q)
    # print("h=", r)
    # for i in range(len(h)):
    #     if h[i]==0 and i==len(h)-1:
    #         NTRUEncKegGen(n, p, q)
    #     else:
    #         continue

    # NtEkg.append(f)
    # NtEkg.append(h)

    # print("NtEkgf=",NtEkg[0])
    # print("NtEkgh=",NtEkg[1])
    return f,r


# NTRUEncKegGen(32, [1,2], 65)
# NTRUEncKegGen(32, 2, 65)


def NTRUSinKegGen(n,q,l,sigam):
    f1 = np.random.randint(1, 100000, n+1)
    f1 = f1.tolist()
    f = pol.PoyMod(f1, q)
    #print("f1=", f1)
    #print("f=", f)
    g1 =np.random.randint(1, 100000, n+1)
    g1 = g1.tolist()
    g = pol.PoyMod(g1, q)
    #print("g1=", g1)
    #print("g=", g)
    sumf = 0
    sumg = 0
    for i in range(len(f)):
        sumf = sumf + f[i] * f[i]
    #print("sumf=",sumf)
    for i in range(len(g)):
        sumg = sumg + g[i] * g[i]
    #print("sumg=",sumg)
    # print("n * sigam * sigam=",n * sigam * sigam)
    #print("n * sigam * sigam=",n * sigam * sigam)
    if sumf >= n * sigam * sigam or sumg >= n * sigam * sigam:
        print("密钥生成失败")
        NTRUSinKegGen(n, q, l, sigam)
    list1=[]
    HList=[]
    list1.append(f)
    list1.append(g)
    M=np.array(list1)
    #print("M=",M)
    # D, L, R = smith_normal_form(M)
    # assert np.allclose(np.dot(L, np.dot(M, R)), D)
    # print("D=",D)
    # print()
    H1, L = row_style_hermite_normal_form(M)
    # H1,L1=column_style_hermite_normal_form(M)
    assert np.allclose(np.dot(L, M), H1)
    #print("H1=", H1)
    for i in range(len(H1)):
        H=pol.PoyMod(H1[i],q)
        HList.append(H)
    #print("HList=", HList)
    # print("H1",H1)
    HMax=np.array(HList)
    #print("HMax=",HMax)
    F=HList[0]
    G=HList[1]
    # Lists=H.tolist()
    #print("Lists=",Lists)
    # G1=Lists.pop()
    # G=pol.PoyMod(G1,q)
    # #print("G=",G)
    # F1=Lists.pop(0)
    # F=pol.PoyMod(F1,q)
    #print("F=",F)
    # H=np.vstack(F,G)
    # ML=np.vstack((M,H))
    # print("ML",ML)

    result=pol.Subtraction2(pol.Multiplication2(f,G,q),pol.Multiplication2(g,F,q),q)
    #print("result=",result)
    sumre=0
    for i in range(len(result)):
        sumre=sumre+result[i]*result[i]
        #print("sumre=", sumre)
    if sumre<(n*n*sigam*sigam*l):
        sk1=np.vstack((M,HMax))
        sk=sk1.tolist()
        # sh1=np.
        #print("sk=",sk)
    h,r=pol.Division(g,f,q)
    # print("sigh=",r)
    # print("sk=",sk)
    return sk,r


# n=int(Euler(30,128))
# q,l=conmodl(65,128)
# #
# #
# NTRUSinKegGen(n,q,l,125)

def NtruGroupGen(q1,l,N,p,sigam):
    q,l=conmodl(q1,l)
    n=Euler(l)
    fKeg=[]
    hKeg=[]
    sigskkeg=[]
    sigpkKeg=[]
    for i in range(N):
        #print("i=",i)
        f,h=NTRUEncKegGen(n,p,q)
        fKeg.append(f)
        hKeg.append(h)

        sk,hpk=NTRUSinKegGen(n,q,l,sigam)
        sigskkeg.append(sk)
        sigpkKeg.append(hpk)
    # print("fkeg=", fKeg)
    # print("hKeg=", hKeg)
    # print("sigskkeg=", sigskkeg)
    # print("sigpkkeg=", sigpkKeg)
    af=0
    ah = 0
    ask=0
    ahpk=0
    # for i in range(len(fKeg)):
    #     for j in range(len(fKeg[i])):
    #         af=sys.getsizeof(fKeg[i][j]) / 1024+af
    #     # af=(len(bin(f[i]))-2)+af
    # # print("af=",af)

    for i in range(len(hKeg)):
        for j in range(len(hKeg[i])):
            ah = sys.getsizeof(hKeg[i][j]) / 1024 + ah
        # ah=(len(bin(h[i]))-2)+ah
    # print("ah=",ah)
    for i in range(len(sigskkeg)):
        for j in range(len(sigskkeg[i])):
            for k in range(len(sigskkeg[i][j])):
                ask = sys.getsizeof(sigskkeg[i][j][k]) / 1024 + ask
            # ask = (len(bin(sk[i][j]))-2) + ask
    # print("ask=", ask)
    for i in range(len(sigpkKeg)):
        for j in range(len(sigpkKeg[i])):
            ahpk = sys.getsizeof(sigpkKeg[i][j]) / 1024 + ahpk
        # ahpk = (len(bin(hpk[i]))-2) + ahpk
    # print("ahpk=", ahpk)
    print("签名私钥的长度为：",ask)
    print("签名公钥的长度为：",ah+ahpk)
    return fKeg,hKeg,sigskkeg,sigpkKeg
#
NtruGroupGen(61,15,1,3,1678)

# NtruGroupGen(q1,l,N,p,sigam)
#用到的参数有：参数q,l,p,sigam,N


end_time = time()
#
run_time = end_time - begin_time
print("run_time=", run_time)
