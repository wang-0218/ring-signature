import Polynomial as pol
from time import *
import KegGen as kg
import numpy as np
begin_time = time()
